Some assets contained in this folder have a license (CC BY-SA 3.0) http://creativecommons.org/licenses/by-sa/3.0/

It means, you can freely use them if you include in the credits the creator of each asset.

- vx_chara03_e.png & Player.png
 * Credits: Tekepon 
 * Source: https://vxresource.wordpress.com/2010/03/29/o-mai-gaad-its-an-update/

- animals.png
 * Credits: aweryn
 * Source: https://vxresource.wordpress.com/2010/02/08/animals-creatures/

- Monstervine_b.png
 * Credits: aweryn
 * Source: https://vxresource.wordpress.com/2010/02/08/monster-sheet-part-2/
