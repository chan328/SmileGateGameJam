Some assets contained in this folder have a license (CC BY-SA 3.0) http://creativecommons.org/licenses/by-sa/3.0/

It means, you can freely use them if you include in the credits the creator of each asset.

- macks_A1.png
- macks_A2.png
- macks_A3.png
- macks_A4.png
- macks_A5.png
- macks_B.png
- macks_C.png
- macks_D.png
- macks_E.png
 * Credits: Mack
 * Source: https://vxresource.wordpress.com/2010/03/17/the-real-macks-tileset/